let PRODUCTS = [];
let productsLoaded = false;
let productsLoadError = "";

const main = document.querySelector("#main");
const cart = new Map();
let activeCategory = "Todas";
let toastTimer;
let agentConversationId = null;
let pendingAgentFiles = [];
let agentRequestInFlight = false;
const CHAT_API_BASE_URL = (window.RIOCLARO_CHAT_API_BASE_URL || "").replace(/\/+$/, "");
let turnstileWidgetId = null;
const MAX_AGENT_FILES = 5;
const MAX_AGENT_FILE_BYTES = 10 * 1024 * 1024;
const ALLOWED_AGENT_EXTENSIONS = new Set([
  "pdf", "txt", "md", "json", "html", "xml", "doc", "docx", "rtf", "odt",
  "ppt", "pptx", "csv", "tsv", "xls", "xlsx", "png", "jpg", "jpeg", "gif", "webp",
]);
const agentHistory = [{
  role: "assistant",
  content: "¡Hola! Soy Toñito de Río Claro. ¿En qué puedo ayudarte?",
}];

const money = (value) => `$${value.toLocaleString("es-MX")} MXN`;
const productById = (id) => PRODUCTS.find((product) => product.id === id);
const escapeHtml = (value) => String(value).replace(/[&<>"']/g, (character) => ({
  "&": "&amp;",
  "<": "&lt;",
  ">": "&gt;",
  '"': "&quot;",
  "'": "&#39;",
})[character]);

function productIllustration(product) {
  const colors = {
    Limpieza: ["#d9eee8", "#0b6b63", "#f0c866"],
    Higiene: ["#f5e9d8", "#bd795c", "#e7b5a2"],
    Farmacia: ["#e6edf5", "#507d95", "#d9a441"],
  };
  const [background, accent, detail] = colors[product.category] || colors.Limpieza;
  const name = product.name.normalize("NFD").replace(/[\u0300-\u036f]/g, "").toLowerCase();
  let shape;

  if (/papel|rollo|panuel/.test(name)) {
    shape = `<g fill="#fffdf8" stroke="${accent}" stroke-width="4">
      <rect x="74" y="58" width="57" height="102" rx="25"/><rect x="131" y="48" width="57" height="112" rx="25"/>
      <ellipse cx="102" cy="82" rx="10" ry="15" fill="${background}"/><ellipse cx="159" cy="72" rx="10" ry="15" fill="${background}"/>
      <path d="M75 132h111" stroke="${detail}" stroke-width="8" stroke-linecap="round"/>
    </g>`;
  } else if (/termometro|cepillo|rastrillo|escoba|trapeador|fibra|esponja|hisopo|venda/.test(name)) {
    shape = `<g fill="none" stroke="${accent}" stroke-linecap="round" stroke-linejoin="round" stroke-width="8">
      <path d="M126 52v96m0 0-30 27m30-27 30 27"/>
      <path d="M102 164h48m-38 0-6 15m26-15 6 15"/>
      <circle cx="126" cy="48" r="13" fill="${detail}" stroke="${accent}" stroke-width="5"/>
    </g>`;
  } else if (/pastilla|tableta|capsula|paracetamol|ibuprofeno|aspirina|loratadina|omeprazol|antigripal|vitamina|curitas|antiacido/.test(name)) {
    shape = `<g stroke="${accent}" stroke-width="5" stroke-linejoin="round">
      <path d="m88 66 75 4 9 97-84 3z" fill="#fff"/><path d="m91 83 69 4 3 26-69-4z" fill="${accent}"/>
      <circle cx="116" cy="143" r="8" fill="${detail}" stroke="none"/><circle cx="143" cy="145" r="8" fill="${detail}" stroke="none"/>
      <path d="M106 126h38" stroke="${background}" stroke-linecap="round"/>
    </g>`;
  } else if (/panal|bebe/.test(name)) {
    shape = `<g stroke="${accent}" stroke-width="5" stroke-linejoin="round">
      <path d="m79 71 33 8 15 31 16-31 34-8-12 77-38 23-38-23z" fill="#fff" />
      <path d="m112 79 15 31 16-31M93 130h78" fill="none" stroke="${detail}" stroke-linecap="round"/>
    </g>`;
  } else if (/detergente|algodon|bolsa|sales|hisop/.test(name)) {
    shape = `<g stroke="${accent}" stroke-width="5" stroke-linejoin="round">
      <path d="m92 59 20 9h29l20-9 13 19-8 88q-2 12-14 12H99q-13 0-14-12l-8-88z" fill="#fff"/>
      <path d="M87 102h78v30H87z" fill="${detail}" stroke="none"/><path d="M107 153h40" stroke="#fff" stroke-linecap="round"/>
    </g>`;
  } else {
    shape = `<g stroke="${accent}" stroke-width="5" stroke-linejoin="round">
      <path d="M103 56h46v18l15 15v81q0 12-13 12h-50q-13 0-13-12V89l15-15z" fill="#fff"/>
      <path d="M103 56h46v18h-46z" fill="${detail}"/>
      <path d="M95 112h62v34H95z" fill="${background}" stroke="none"/>
      <path d="M109 129h34" stroke="${accent}" stroke-linecap="round"/>
    </g>`;
  }

  const svg = `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 256 216">
    <rect x="8" y="8" width="240" height="200" rx="32" fill="${background}"/>
    <ellipse cx="128" cy="184" rx="54" ry="8" fill="${accent}" opacity=".13"/>
    ${shape}
  </svg>`;
  return `data:image/svg+xml,${encodeURIComponent(svg)}`;
}

function productCard(product) {
  return `
    <article class="product-card">
      <div class="product-media">
        <span class="product-chip">${escapeHtml(product.category)}</span>
        <img src="${productIllustration(product)}" alt="Ilustración minimalista de ${escapeHtml(product.name)}" loading="lazy" width="360" height="260">
      </div>
      <div class="product-info">
        <span class="eyebrow">CATÁLOGO DE REFERENCIA</span>
        <h3>${escapeHtml(product.name)}</h3>
        <p>${escapeHtml(product.description)}</p>
        <div class="product-detail">
          <div class="product-price"><strong>${money(product.price)}</strong><small>Precio referencial</small></div>
          <div>
            <span class="sample-stock">${product.stock} · existencias de referencia</span>
            <button class="add-button" type="button" data-add="${escapeHtml(product.id)}" aria-label="Agregar ${escapeHtml(product.name)} a la solicitud">+</button>
          </div>
        </div>
      </div>
    </article>`;
}

function notice(extraClass = "") {
  return `<div class="notice ${extraClass}" role="note">
    <span class="notice-mark" aria-hidden="true">!</span>
    <div><strong>Precios y existencias de referencia</strong>
      <p>Confirma precios y disponibilidad con la empresa antes de ofrecer estos productos.</p>
    </div>
  </div>`;
}

function pageHero(eyebrow, title, copy, crumbs = "", variant = "general") {
  return `<section class="page-hero page-hero-${variant}"><div class="container">
    ${crumbs ? `<div class="breadcrumb"><a href="#/">Inicio</a> &nbsp;›&nbsp; ${crumbs}</div>` : ""}
    <span class="eyebrow">${eyebrow}</span><h1>${title}</h1><p>${copy}</p>
  </div></section>`;
}

function memberCard() {
  return `<aside class="home-member-card" aria-label="Inicio de sesión de miembros">
    <span class="eyebrow">PORTAL DE CLIENTES</span>
    <h2>¿Aún no ha realizado su pedido?</h2>
    <p class="member-sign-in">Inicie sesión aquí</p>
    <form class="member-login-form" data-demo-auth-form>
      <label for="member-email">Correo electrónico</label>
      <input id="member-email" name="email" type="email" placeholder="tu@correo.com" autocomplete="off" required>
      <label for="member-password">Contraseña</label>
      <input id="member-password" name="password" type="password" placeholder="••••••••" autocomplete="off" required>
      <button class="button button-primary button-full" type="submit">Iniciar sesión <span aria-hidden="true">→</span></button>
    </form>
    <p class="member-create">¿Aún no tienes cuenta? <a href="#/cuenta">Crear una cuenta</a></p>
    <p class="agent-privacy">Acceso de demostración: no se crean cuentas ni se guardan contraseñas.</p>
  </aside>`;
}

function homePage() {
  const featured = [...new Set(PRODUCTS.map((product) => product.category))]
    .map((category) => PRODUCTS.find((product) => product.category === category))
    .filter(Boolean);
  return `<div class="page">
    <section class="home-hero">
      <div class="hero-inner">
        <div class="hero-copy">
          <span class="eyebrow">ABASTECIMIENTO PARA NEGOCIOS</span>
          <h1>Lo esencial para tu negocio, <span>en un solo lugar.</span></h1>
          <p>Encuentra productos de limpieza, higiene y farmacia, y consulta precios y existencias de referencia.</p>
          <div class="hero-actions">
            <a class="button button-light" href="#/productos">Explorar productos <span aria-hidden="true">→</span></a>
            <a class="button" href="#/pedido" style="border-color:rgb(255 255 255 / 35%);color:#fff">Crear solicitud</a>
          </div>
          <p class="hero-footnote">Abasto confiable y atención cercana para tu negocio.</p>
          <div class="hero-proof"><span><span class="proof-mark">✳</span> Catálogo mayorista</span><span><span class="proof-mark">✳</span> Solicitudes de pedido</span><span><span class="proof-mark">✳</span> Atención al cliente</span></div>
        </div>
        ${memberCard()}
      </div>
    </section>
    <div class="trust-row"><span><strong>${PRODUCTS.length}</strong> productos en catálogo</span><span><strong>${new Set(PRODUCTS.map((product) => product.category)).size}</strong> categorías</span><span>Catálogo informativo</span><span>Atención para clientes y distribuidores</span></div>
    <section class="section"><div class="container">
      <div class="section-heading"><div><span class="eyebrow">Selección para tu negocio</span><h2>Productos destacados</h2></div><a class="text-link" href="#/productos">Ver catálogo completo <span aria-hidden="true">→</span></a></div>
      ${notice("notice-compact")}
      <div class="product-grid">${featured.map(productCard).join("")}</div>
    </div></section>
    <section class="section" style="padding-top:10px"><div class="container">
      <div class="section-heading"><div><span class="eyebrow">Explora por categoría</span><h2>Lo que tu negocio necesita</h2></div><p>Encuentra productos de limpieza, higiene y farmacia.</p></div>
      <div class="category-grid">
        ${[...new Set(PRODUCTS.map((product) => product.category))].map((category) => `<a class="category-card" href="#/productos"><span class="category-ornament" aria-hidden="true"></span><small>Productos para tu negocio</small><h3>${escapeHtml(category)}</h3></a>`).join("")}
      </div>
    </div></section>
    <section class="section-tight"><div class="container">    <div class="cta-band"><div><h2>Prepara tu solicitud</h2><p>El catálogo permite armar una selección; pide orientación en el chat Servicioalcliente.</p></div><a class="button button-light" href="#/pedido">Armar solicitud <span aria-hidden="true">→</span></a></div></div></section>
  </div>`;
}

function productsPage() {
  return `<div class="page">
    ${pageHero("CATÁLOGO MAYORISTA", "Nuestros productos", "Explora categorías y agrega artículos a una solicitud. Precios y existencias son de referencia.", "Productos", "productos")}
    <section class="section-tight"><div class="container">
      ${notice()}
      <div class="catalog-toolbar">
        <div class="filter-row" role="group" aria-label="Filtrar por categoría">
          ${["Todas", ...new Set(PRODUCTS.map((product) => product.category))].map((category) => `<button class="filter-chip" type="button" data-category="${category}" aria-pressed="${category === activeCategory}">${category}</button>`).join("")}
        </div>
        <label class="search-field"><span class="visually-hidden">Buscar producto</span><input id="product-search" type="search" placeholder="Buscar en el catálogo…" autocomplete="off"></label>
      </div>
      <div class="results-note"><span id="results-count">${PRODUCTS.length} productos</span><span>Precios y existencias por confirmar</span></div>
      <div class="product-grid" id="product-grid"></div>
    </div></section>
  </div>`;
}

function aboutPage() {
  return `<div class="page">
    ${pageHero("QUIÉNES SOMOS", "Abasto cercano, relaciones duraderas", "Somos una distribuidora de la Ciudad de México que ayuda a negocios locales a surtirse con productos esenciales para el día a día.", "Quiénes somos", "oficina")}
    <section class="section"><div class="container editorial-grid">
      <div class="editorial-art" role="img" aria-label="Fachada y almacén de la tienda Río Claro"></div>
      <div class="editorial-copy"><span class="eyebrow">Nuestra historia</span><h2>Un aliado para el crecimiento de tu negocio.</h2>
        <p>Río Claro nació en la Ciudad de México en 2014 con una idea sencilla: hacer más fácil el abastecimiento de los comercios de barrio. Empezamos atendiendo a pequeños negocios de la capital y, con el tiempo, ampliamos nuestro catálogo para reunir productos de limpieza, higiene y farmacia en un mismo lugar.</p>
        <p>Hoy buscamos construir relaciones cercanas con clientes y distribuidores de la Ciudad de México y su zona metropolitana, escuchando sus necesidades y ayudándoles a encontrar opciones para mantener sus negocios en movimiento.</p>
      </div>
    </div></section>
    <section class="section" style="padding-top:0"><div class="container">
      <div class="section-heading"><div><span class="eyebrow">Lo que nos guía</span><h2>Nuestra misión y visión</h2></div></div>
      <div class="values-grid">
        <article class="value-card"><span class="value-number">01</span><h3>Misión</h3><p>Ofrecer a comercios y distribuidores un surtido confiable de productos esenciales, con atención cercana y un servicio ágil.</p></article>
        <article class="value-card"><span class="value-number">02</span><h3>Visión</h3><p>Ser un aliado mayorista reconocido en la Ciudad de México por facilitar el abastecimiento y las relaciones de largo plazo.</p></article>
        <article class="value-card"><span class="value-number">03</span><h3>Valores</h3><p>Trabajamos con responsabilidad, trato honesto, compromiso con nuestros clientes y mejora continua.</p></article>
      </div>
    </div></section>
  </div>`;
}

function cartContents() {
  const entries = [...cart.entries()];
  if (!entries.length) {
    return `<div class="cart-empty"><strong>Aún no has agregado productos a esta solicitud.</strong>Elige artículos del catálogo para continuar.</div>
      <a class="button button-outline button-full" href="#/productos" style="margin-top:14px">Explorar productos</a>`;
  }
  const total = entries.reduce((sum, [id, quantity]) => sum + productById(id).price * quantity, 0);
  return `<div class="cart-list">${entries.map(([id, quantity]) => {
    const product = productById(id);
    return `<div class="cart-line"><strong>${product.name}</strong><small>${money(product.price)} · precio de referencia</small>
      <div class="quantity-controls"><button type="button" data-qty="minus" data-id="${id}" aria-label="Reducir ${product.name}">−</button><span>${quantity}</span><button type="button" data-qty="plus" data-id="${id}" aria-label="Aumentar ${product.name}">+</button><button type="button" data-qty="remove" data-id="${id}" style="margin-left:auto;width:auto;padding-inline:8px;color:#8a5042" aria-label="Quitar ${product.name}">Quitar</button></div>
    </div>`;
  }).join("")}</div><div class="cart-total"><span>Total de referencia</span><strong>${money(total)}</strong></div>`;
}

function orderPage() {
  const hasItems = cart.size > 0;
  return `<div class="page">
    ${pageHero("SOLICITUD DE PEDIDO", "Arma tu pedido", "Prepara una solicitud con los artículos seleccionados. Para recibir orientación, abre el chat de Servicioalcliente.", "Solicitar pedido", "ciudad")}
    <section class="section-tight"><div class="container">
      ${notice("notice-compact")}
      <div class="form-layout">
        <section class="form-card">
          <span class="eyebrow">SOLICITUD</span><h2>Datos de contacto</h2>
          <p class="form-intro">Completa estos campos para preparar tu solicitud. Actualmente no se envía ni se guarda información.</p>
          <form id="order-form">
            <div class="field-grid">
              <div class="field"><label for="order-type">Tipo de cliente</label><select id="order-type" name="type" required><option value="" selected disabled>Selecciona una opción</option><option>Cliente</option><option>Distribuidor</option><option>Negocio o comercio</option></select></div>
              <div class="field"><label for="order-name">Nombre o negocio</label><input id="order-name" name="name" placeholder="Nombre de contacto" required></div>
            </div>
            <div class="field-grid">
              <div class="field"><label for="order-email">Correo</label><input id="order-email" name="email" type="email" placeholder="correo@empresa.com" required></div>
              <div class="field"><label for="order-phone">Teléfono</label><input id="order-phone" name="phone" type="tel" placeholder="10 dígitos" pattern="[0-9]{10}" required></div>
            </div>
            <div class="field"><label for="order-notes">Nota <span class="field-hint">(opcional)</span></label><textarea id="order-notes" name="notes" placeholder="Agrega detalles de tu solicitud."></textarea></div>
            <div class="form-row-end"><span class="status-pill">El envío aún no está habilitado</span><button class="button button-primary" type="submit" ${hasItems ? "" : "disabled"}>Preparar solicitud <span aria-hidden="true">→</span></button></div>
            <p class="form-feedback" id="order-feedback" aria-live="polite"></p>
            <p class="disclaimer">Los datos de este formulario no se envían ni guardan. Confirma disponibilidad y precios con la empresa.</p>
          </form>
        </section>
        <aside class="side-card"><h2>Tu selección</h2><p>Los importes usan precios de referencia por confirmar.</p><div id="cart-summary">${cartContents()}</div><p class="agent-order-help">¿Necesitas ayuda con tu pedido? <button class="inline-chat-link" type="button" data-open-support>Pregunta a Toñito</button></p></aside>
      </div>
    </div></section>
  </div>`;
}

function accountPage() {
  return `<div class="page">
    ${pageHero("CUENTA DE MIEMBROS", "Y tu ¿Ya te asociaste?", "Inicie sesión aquí. También puedes crear una cuenta de demostración para conocer el flujo.", "Cuenta de miembros", "cuenta")}
    <section class="section-tight"><div class="container account-layout">
      <div class="account-promo"><span class="eyebrow">PORTAL DE CLIENTES</span><h2>Un espacio para clientes y distribuidores.</h2><p>Esta demo muestra la experiencia de acceso; todavía no valida usuarios ni guarda contraseñas.</p></div>
      <section class="account-card">
        <span class="eyebrow">MI CUENTA</span><h2>Haga su pedido</h2><p class="form-intro">Elige una opción para continuar. No ingreses una contraseña que uses en otros sitios.</p>
        <div class="account-tabs" role="tablist" aria-label="Opciones de cuenta">
          <button class="account-tab" type="button" role="tab" aria-selected="true" data-account-tab="access">Iniciar sesión</button>
          <button class="account-tab" type="button" role="tab" aria-selected="false" data-account-tab="create">Crear cuenta</button>
        </div>
        <form id="account-form">
          <div class="field" data-account-fields="access"><label for="account-email">Correo electrónico</label><input id="account-email" name="email" type="email" placeholder="tu@correo.com" autocomplete="off" required></div>
          <div class="field" data-account-fields="access"><label for="account-password">Contraseña</label><input id="account-password" name="password" type="password" placeholder="••••••••" autocomplete="off" required></div>
          <div class="field" data-account-fields="create" hidden><label for="account-name">Nombre</label><input id="account-name" name="name" placeholder="Nombre de contacto" autocomplete="off"></div>
          <div class="field" data-account-fields="create" hidden><label for="create-email">Correo electrónico</label><input id="create-email" name="create_email" type="email" placeholder="tu@correo.com" autocomplete="off"></div>
          <div class="field" data-account-fields="create" hidden><label for="create-password">Crear contraseña</label><input id="create-password" name="create_password" type="password" placeholder="Mínimo 8 caracteres" autocomplete="off" minlength="8"></div>
          <p class="disclaimer" id="account-copy">Inicie sesión aquí. El acceso no está conectado en esta demo.</p>
          <button class="button button-primary button-full account-action" id="account-action" type="submit">Iniciar sesión <span aria-hidden="true">→</span></button>
          <p class="form-feedback" id="account-feedback" aria-live="polite"></p>
          <p class="disclaimer">Los datos de esta demostración no se envían ni se guardan.</p>
        </form>
      </section>
    </div></section>
  </div>`;
}

function contactPage() {
  return `<div class="page">
    ${pageHero("CONTÁCTANOS", "Estamos para ayudarte", "Comunícate con nuestro equipo para resolver dudas sobre el catálogo y la atención a clientes.", "Contáctanos", "contacto")}
    <section class="section-tight"><div class="container contact-grid">
      <div><span class="eyebrow">CONTACTO</span><h2 style="margin:12px 0">Atención en Ciudad de México</h2><p style="color:var(--muted)">Nuestro equipo está disponible para atender consultas de clientes y distribuidores en la capital.</p>
        <div class="contact-list">
          <div class="contact-item"><span class="contact-symbol" aria-hidden="true">T</span><div><small>TELÉFONO</small><strong>+52 55 9142 9790</strong></div></div>
          <div class="contact-item"><span class="contact-symbol" aria-hidden="true">W</span><div><small>WHATSAPP</small><strong>+52 55 2128 3837</strong></div></div>
          <div class="contact-item"><span class="contact-symbol" aria-hidden="true">@</span><div><small>CORREO</small><strong>+52 55 3721 3108</strong></div></div>
          <div class="contact-item"><span class="contact-symbol" aria-hidden="true"><img class="contact-country-icon" src="assets/mexico-map-icon.png" alt=""></span><div><small>DIRECCIÓN</small><strong>Av. Río Claro 1146, Col. Centro, Alcaldía Cuauhtémoc, Ciudad de México, CDMX.</strong></div></div>
          <div class="contact-item"><span class="contact-symbol" aria-hidden="true">◷</span><div><small>HORARIO DE ATENCIÓN</small><strong>Lunes a Viernes de 8:00 a.m. a 3:00 p.m. y Sábados de 10:00 a.m. a 1:00 p.m.</strong></div></div>
          <div class="contact-item"><span class="contact-symbol" aria-hidden="true"><svg viewBox="0 0 32 32" focusable="false"><circle cx="16" cy="16" r="13" fill="#bfe7d8" stroke="currentColor" stroke-width="1.5"/><path d="m7.2 11.1 2.2-3.5 3.8-.9 2.1 1.8-.6 2.3-2.4 1.4-.7 2.3-2.1.1-.7-1.8-1.6-.4zm7.1 2.3 2.5-.8 2.2 1.1 2.3-.1 2.1 2.2-.8 2.2-2.8.7-1.1 2.1-1.9 1.6-.4 3.2-1.7-1.4-.2-3.8-1.5-2.8.4-2.5zm8.3-6.1 2.4 1.6 1.3 2.4-1.9.8-2-1.5z" fill="currentColor"/></svg></span><div><small>REDES SOCIALES</small><strong>+52 744 321 6920</strong></div></div>
        </div>
      </div>
      <section class="form-card"><span class="eyebrow">ATENCIÓN A CLIENTES</span><h2>Déjanos tu consulta</h2><p class="form-intro">El formulario de contacto es demostrativo y no está conectado.</p>
        <form id="contact-form">
          <div class="field-grid"><div class="field"><label for="contact-name">Nombre</label><input id="contact-name" name="name" placeholder="Nombre de contacto" required></div>
          <div class="field"><label for="contact-type">Tipo de cliente</label><select id="contact-type" name="type"><option>Cliente</option><option>Distribuidor</option></select></div></div>
          <div class="field"><label for="contact-email">Correo</label><input id="contact-email" name="email" type="email" placeholder="correo@empresa.com" required></div>
          <div class="field"><label for="contact-message">Consulta</label><textarea id="contact-message" name="message" placeholder="Escribe tu consulta." required></textarea></div>
          <button class="button button-primary" type="submit">Enviar consulta <span aria-hidden="true">→</span></button>
          <p class="form-feedback" id="contact-feedback" aria-live="polite"></p>
          <p class="disclaimer">Este formulario no envía ni guarda mensajes.</p>
        </form>
      </section>
    </div></section>
  </div>`;
}

const ROUTES = {
  "/": homePage,
  "/nosotros": aboutPage,
  "/productos": productsPage,
  "/pedido": orderPage,
  "/cuenta": accountPage,
  "/contacto": contactPage,
};

function showToast(message) {
  const toast = document.querySelector("#toast");
  toast.textContent = message;
  toast.classList.add("show");
  window.clearTimeout(toastTimer);
  toastTimer = window.setTimeout(() => toast.classList.remove("show"), 2800);
}

function updateCartBadge() {
  const count = [...cart.values()].reduce((sum, quantity) => sum + quantity, 0);
  document.querySelector("#cart-count").textContent = String(count);
}

function updateCatalog() {
  const grid = document.querySelector("#product-grid");
  if (!grid) return;
  const count = document.querySelector("#results-count");
  if (!productsLoaded) {
    grid.innerHTML = `<p role="status">Cargando catálogo…</p>`;
    count.textContent = "Cargando…";
    return;
  }
  if (productsLoadError) {
    grid.innerHTML = `<div class="empty-state" style="grid-column:1/-1"><h3>No pudimos cargar el catálogo</h3><p role="alert"></p></div>`;
    grid.querySelector('[role="alert"]').textContent = productsLoadError;
    count.textContent = "No disponible";
    return;
  }
  const query = document.querySelector("#product-search").value.trim().toLocaleLowerCase("es-MX");
  const filtered = PRODUCTS.filter((product) => {
    const matchesCategory = activeCategory === "Todas" || product.category === activeCategory;
    const matchesQuery = `${product.name} ${product.category}`.toLocaleLowerCase("es-MX").includes(query);
    return matchesCategory && matchesQuery;
  });
  grid.innerHTML = filtered.length
    ? filtered.map(productCard).join("")
    : `<div class="empty-state" style="grid-column:1/-1"><h3>No hay coincidencias</h3><p>Prueba otra palabra o categoría.</p></div>`;
  count.textContent = `${filtered.length} ${filtered.length === 1 ? "producto" : "productos"}`;
}

function cleanAgentAnswer(answer) {
  return answer
    .replace(/ ?【\d+:\d+†source】/g, "")
    .replace(/[ \t]+\n/g, "\n")
    .replace(/\n{3,}/g, "\n\n")
    .trim();
}

function renderAgentHistory() {
  document.querySelectorAll("[data-agent-messages]").forEach((container) => {
    container.replaceChildren(...agentHistory.map(({ role, content, files }) => {
      const message = document.createElement("article");
      message.className = `agent-message agent-message-${role}`;
      const label = document.createElement("strong");
      label.textContent = role === "user" ? "Tú" : role === "error" ? "Conexión" : "Toñito";
      const text = document.createElement("p");
      text.textContent = content;
      message.append(label, text);
      if (files?.length) {
        const attachmentNames = document.createElement("small");
        attachmentNames.className = "agent-attachment-names";
        attachmentNames.textContent = `Adjuntos: ${files.join(", ")}`;
        message.append(attachmentNames);
      }
      return message;
    }));
    container.scrollTop = container.scrollHeight;
  });
}

function renderAgentFiles() {
  document.querySelectorAll("[data-agent-file-list]").forEach((list) => {
    list.replaceChildren(...pendingAgentFiles.map((file, index) => {
      const chip = document.createElement("span");
      chip.className = "agent-file-chip";
      const name = document.createElement("span");
      name.textContent = `${file.name} · ${(file.size / 1024).toFixed(0)} KB`;
      const remove = document.createElement("button");
      remove.type = "button";
      remove.textContent = "×";
      remove.setAttribute("aria-label", `Quitar ${file.name}`);
      remove.addEventListener("click", () => {
        pendingAgentFiles.splice(index, 1);
        renderAgentFiles();
      });
      chip.append(name, remove);
      return chip;
    }));
  });
}

async function sendAgentMessage(form) {
  const input = form.elements.namedItem("message");
  const feedback = form.querySelector("[data-agent-feedback]");
  const submitButton = form.querySelector('button[type="submit"]');
  const attachButton = form.querySelector("[data-agent-attach]");
  const message = input.value.trim();
  if (!CHAT_API_BASE_URL) {
    feedback.textContent = "El chat aún no está conectado. Intenta de nuevo más tarde.";
    return;
  }
  const turnstileToken = turnstileWidgetId === null
    ? ""
    : window.turnstile?.getResponse(turnstileWidgetId) || "";
  if (window.RIOCLARO_TURNSTILE_SITE_KEY && !turnstileToken) {
    feedback.textContent = "Completa la verificación antiabuso antes de enviar.";
    return;
  }
  if (!message && pendingAgentFiles.length === 0) {
    feedback.textContent = "Escribe un mensaje o adjunta un archivo.";
    return;
  }
  if (agentRequestInFlight) return;

  const files = [...pendingAgentFiles];
  const pendingMessage = { role: "pending", content: "Toñito está escribiendo…" };
  agentHistory.push({
    role: "user",
    content: message || "Revisa los archivos adjuntos y ayúdame.",
    files: files.map((file) => file.name),
  }, pendingMessage);
  renderAgentHistory();
  feedback.textContent = "";
  input.value = "";
  input.disabled = true;
  submitButton.disabled = true;
  attachButton.disabled = true;
  agentRequestInFlight = true;

  try {
    const formData = new FormData();
    formData.append("message", message);
    formData.append("turnstile_token", turnstileToken);
    if (agentConversationId) formData.append("conversation_id", agentConversationId);
    files.forEach((file) => formData.append("files", file, file.name));
    const response = await fetch(`${CHAT_API_BASE_URL}/api/chat`, { method: "POST", body: formData });
    const payload = await response.json();
    if (!response.ok) throw new Error(payload.detail || payload.error || "No pudimos conectar con el asistente.");
    if (typeof payload.answer !== "string" || !payload.answer.trim()) {
      throw new Error("El asistente no devolvió una respuesta. Intenta de nuevo.");
    }
    const answer = cleanAgentAnswer(payload.answer);
    if (!answer) {
      throw new Error("El asistente no devolvió una respuesta que se pueda mostrar. Intenta de nuevo.");
    }
    if (typeof payload.conversation_id !== "string" || !payload.conversation_id) {
      throw new Error("El asistente no devolvió una conversación válida. Intenta de nuevo.");
    }
    agentConversationId = payload.conversation_id;
    pendingAgentFiles = [];
    renderAgentFiles();
    const pendingIndex = agentHistory.indexOf(pendingMessage);
    if (pendingIndex === -1) throw new Error("La conversación cambió. Vuelve a intentarlo.");
    agentHistory.splice(pendingIndex, 1, {
      role: "assistant",
      content: answer,
    });
  } catch (error) {
    const pendingIndex = agentHistory.indexOf(pendingMessage);
    if (pendingIndex !== -1) agentHistory.splice(pendingIndex, 1);
    agentHistory.push({ role: "error", content: error.message || "No pudimos conectar con el asistente." });
    feedback.textContent = "Verifica la conexión e inténtalo de nuevo.";
    input.value = message;
  } finally {
    if (turnstileWidgetId !== null) window.turnstile?.reset(turnstileWidgetId);
    input.disabled = false;
    submitButton.disabled = false;
    attachButton.disabled = false;
    agentRequestInFlight = false;
    renderAgentHistory();
    input.focus();
  }
}

async function loadProducts() {
  try {
    const response = await fetch("api/products.json");
    const payload = await response.json();
    if (!response.ok) throw new Error(payload.error || "No se pudo cargar el catálogo.");
    if (!Array.isArray(payload.products) || payload.products.length === 0) {
      throw new Error("El catálogo no contiene productos.");
    }
    PRODUCTS = payload.products;
    productsLoaded = true;
    updateCartBadge();
    const route = location.hash.replace(/^#/, "") || "/";
    if (route === "/" || route === "/productos") render();
  } catch (error) {
    productsLoaded = true;
    productsLoadError = error.message || "Intenta actualizar la página.";
    if ((location.hash.replace(/^#/, "") || "/") === "/productos") updateCatalog();
  }
}

function render() {
  const path = location.hash.replace(/^#/, "") || "/";
  const route = ROUTES[path] ? path : "/";
  main.innerHTML = ROUTES[route]();
  document.querySelectorAll(".primary-nav [data-route]").forEach((link) => {
    if (link.dataset.route === route) link.setAttribute("aria-current", "page");
    else link.removeAttribute("aria-current");
  });
  document.querySelector(".primary-nav").classList.remove("open");
  document.querySelector(".menu-toggle").setAttribute("aria-expanded", "false");
  const supportPanel = document.querySelector("#support-panel");
  const supportLauncher = document.querySelector("#support-launcher");
  supportPanel.hidden = true;
  supportLauncher.hidden = false;
  supportLauncher.setAttribute("aria-expanded", "false");
  if (route === "/productos") updateCatalog();
  if (route === "/pedido") updateCartBadge();
  renderAgentHistory();
  main.focus({ preventScroll: true });
  window.scrollTo({ top: 0, behavior: "smooth" });
}

document.addEventListener("click", (event) => {
  const addButton = event.target.closest("[data-add]");
  if (addButton) {
    const id = addButton.dataset.add;
    cart.set(id, (cart.get(id) || 0) + 1);
    updateCartBadge();
    showToast(`${productById(id).name} agregado a tu solicitud.`);
    updateCatalog();
    return;
  }

  const filter = event.target.closest("[data-category]");
  if (filter) {
    activeCategory = filter.dataset.category;
    document.querySelectorAll("[data-category]").forEach((button) => button.setAttribute("aria-pressed", String(button === filter)));
    updateCatalog();
    return;
  }

  const quantityButton = event.target.closest("[data-qty]");
  if (quantityButton) {
    const { id, qty } = quantityButton.dataset;
    const current = cart.get(id) || 0;
    if (qty === "remove" || (qty === "minus" && current <= 1)) cart.delete(id);
    else if (qty === "minus") cart.set(id, current - 1);
    else cart.set(id, current + 1);
    render();
    return;
  }

  const tab = event.target.closest("[data-account-tab]");
  if (tab) {
    const creating = tab.dataset.accountTab === "create";
    document.querySelectorAll("[data-account-tab]").forEach((button) => button.setAttribute("aria-selected", String(button === tab)));
    document.querySelectorAll("[data-account-fields]").forEach((field) => {
      const active = field.dataset.accountFields === (creating ? "create" : "access");
      field.hidden = !active;
      field.querySelectorAll("input").forEach((input) => {
        input.disabled = !active;
        input.required = active;
      });
    });
    document.querySelector("#account-action").innerHTML = `${creating ? "Crear cuenta" : "Iniciar sesión"} <span aria-hidden="true">→</span>`;
    document.querySelector("#account-copy").textContent = creating
      ? "Registro de demostración: no se crea una cuenta ni se guarda información."
      : "Inicie sesión aquí. El acceso no está conectado en esta demo.";
    document.querySelector("#account-feedback").textContent = "";
    return;
  }

  if (event.target.closest("[data-agent-attach]")) {
    event.target.closest("[data-agent-form]").querySelector("[data-agent-files-input]").click();
    return;
  }

  if (event.target.closest("[data-open-support]")) {
    const panel = document.querySelector("#support-panel");
    panel.hidden = false;
    document.querySelector("#support-launcher").setAttribute("aria-expanded", "true");
    panel.querySelector('textarea[name="message"]').focus();
    return;
  }
});

document.addEventListener("change", (event) => {
  if (!event.target.matches("[data-agent-files-input]")) return;
  const incoming = Array.from(event.target.files || []);
  const combined = [...pendingAgentFiles, ...incoming];
  if (combined.length > MAX_AGENT_FILES) {
    showToast(`Puedes adjuntar hasta ${MAX_AGENT_FILES} archivos por mensaje.`);
    event.target.value = "";
    return;
  }
  if (combined.reduce((size, file) => size + file.size, 0) > MAX_AGENT_FILE_BYTES) {
    showToast("El tamaño total de los archivos no puede superar 10 MB por mensaje.");
    event.target.value = "";
    return;
  }
  const unsupported = incoming.find((file) => {
    const extension = file.name.split(".").pop().toLowerCase();
    return !ALLOWED_AGENT_EXTENSIONS.has(extension);
  });
  if (unsupported) {
    showToast(`${unsupported.name}: adjunta documentos, hojas de cálculo o imágenes comunes. No se aceptan ejecutables.`);
    event.target.value = "";
    return;
  }
  pendingAgentFiles = combined;
  renderAgentFiles();
  event.target.value = "";
});

document.addEventListener("input", (event) => {
  if (event.target.id === "product-search") updateCatalog();
});
document.addEventListener("submit", (event) => {
  if (event.target.matches("[data-agent-form]")) {
    event.preventDefault();
    sendAgentMessage(event.target);
    return;
  }

  if (event.target.id === "account-form") {
    event.preventDefault();
    const creating = document.querySelector('[data-account-tab="create"]').getAttribute("aria-selected") === "true";
    event.target.reset();
    document.querySelector("#account-feedback").textContent = creating
      ? "La cuenta no se creó porque esta es una demostración."
      : "El inicio de sesión no está habilitado en esta demostración.";
    return;
  }

  if (event.target.matches("[data-demo-auth-form]")) {
    event.preventDefault();
    event.target.reset();
    showToast("El inicio de sesión no está habilitado; no se guardó ningún dato.");
    return;
  }

  if (event.target.id === "order-form") {
    event.preventDefault();
    if (cart.size === 0) return;
    cart.clear();
    render();
    const feedback = document.querySelector("#order-feedback");
    if (feedback) feedback.textContent = "La solicitud se preparó, pero todavía no se envía ni registra.";
    showToast("La solicitud todavía no se ha enviado.");
  }

  if (event.target.id === "contact-form") {
    event.preventDefault();
    event.target.reset();
    document.querySelector("#contact-feedback").textContent = "El formulario de contacto aún no está conectado.";
  }
});

window.addEventListener("hashchange", render);

document.querySelector(".menu-toggle").addEventListener("click", (event) => {
  const nav = document.querySelector(".primary-nav");
  const isOpen = nav.classList.toggle("open");
  event.currentTarget.setAttribute("aria-expanded", String(isOpen));
});

document.querySelector("#support-launcher").addEventListener("click", (event) => {
  const panel = document.querySelector("#support-panel");
  const opening = panel.hidden;
  panel.hidden = !opening;
  event.currentTarget.setAttribute("aria-expanded", String(opening));
  if (opening) {
    renderAgentFiles();
    panel.querySelector('textarea[name="message"]').focus();
  }
});
if (window.RIOCLARO_TURNSTILE_SITE_KEY) {
  const turnstileScript = document.createElement("script");
  turnstileScript.src = "https://challenges.cloudflare.com/turnstile/v0/api.js?render=explicit";
  turnstileScript.async = true;
  turnstileScript.defer = true;
  turnstileScript.onload = () => {
    turnstileWidgetId = window.turnstile.render("[data-agent-captcha]", {
      sitekey: window.RIOCLARO_TURNSTILE_SITE_KEY,
      action: "chat",
    });
  };
  turnstileScript.onerror = () => {
    document.querySelector("[data-agent-feedback]").textContent =
      "No se pudo cargar la verificación antiabuso. Intenta de nuevo más tarde.";
  };
  document.head.append(turnstileScript);
}
document.querySelector("#support-close").addEventListener("click", () => {
  document.querySelector("#support-panel").hidden = true;
  document.querySelector("#support-launcher").setAttribute("aria-expanded", "false");
  document.querySelector("#support-launcher").focus();
});
document.addEventListener("keydown", (event) => {
  if (event.key === "Escape" && !document.querySelector("#support-panel").hidden) {
    document.querySelector("#support-close").click();
  }
});

render();
loadProducts();
