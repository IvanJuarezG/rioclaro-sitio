window.RIOCLARO_CHAT_API_BASE_URL = "https://func-rioclaro-dev-3ae3.azurewebsites.net";
window.RIOCLARO_TURNSTILE_SITE_KEY = "";
