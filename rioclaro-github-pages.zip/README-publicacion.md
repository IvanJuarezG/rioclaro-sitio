# Paquete web estático de Río Claro

Este directorio es un paquete separado generado desde `sitio/`; el código fuente original no se modificó.
Incluye 55 productos en `api/products.json`. El frontend usa una ruta relativa para
funcionar tanto en dominios personalizados como en subrutas de GitHub Pages.

## Alcance y limitaciones

- Solo HTML, CSS, JavaScript, imágenes y el catálogo estático; no incluye FastAPI, `SitioWeb.py`,
  dependencias de Python, chat ni acceso a Azure AI Foundry.
- La navegación hash y el catálogo siguen disponibles. La UI del chat se elimina y el código estático
  no realiza solicitudes a `/api/chat`.
- Pedidos, contacto e inicio de sesión siguen siendo demostrativos: no se envía ni persiste información.
- La historia y los datos comerciales/contacto son de demostración; revisarlos antes de difundir la URL.
- El contenido es público y anónimo al publicar este paquete en GitHub Pages.

## Publicar en GitHub Pages

1. Crea un repositorio público nuevo y vacío para el sitio. No subas el proyecto completo: este
   paquete separado no contiene el backend ni los archivos de inventario originales.
2. Sube el contenido de este directorio a la raíz del repositorio, incluida la carpeta
   `.github/workflows`.
3. En **Settings > Pages**, selecciona **GitHub Actions** como origen si GitHub lo solicita.
4. Espera a que termine el workflow **Deploy GitHub Pages** en la pestaña **Actions**. La URL se
   mostrará en **Settings > Pages**.

El repositorio debe ser público para que el sitio sea accesible a cualquier persona con el plan
gratuito de GitHub Pages. Publica únicamente este paquete y confirma los datos ficticios antes de
compartir la URL.
